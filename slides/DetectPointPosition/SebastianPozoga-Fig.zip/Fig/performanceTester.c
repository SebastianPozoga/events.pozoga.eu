#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include "lib.c"

#define PI 3.141592653589793238462


int main()
{

    /* initialize random seed: */
    srand ( time(NULL) );

    //nuber of polygon points
    int n, nmax, nmin, l, t;
    //polygon points
    struct point *p;
    struct point *tests;
    //test point
    struct point tP;
    //helpers
    int i;

    //get polygons interval
    printf("\nPodaj przedzial wielokat�w do testow: ");
    scanf("%d %d", &nmin, &nmax);
    if(nmin<3){
        printf("Wielokat musi skladac sie z conajmniej 3 bokow");
        return 0;
    }
    if(nmin>nmax){
        n=nmin;
        nmin=nmax;
        nmax=nmin;
    }
    printf("\nIlosc zestawow: ");
    scanf("%i", &l);
    if(l<1){
        printf("Ilosc zestawow musi byc liczba naturalna wieksza od 0");
    }
    printf("\nTest na zestaw: ");
    scanf("%i", &t);
    if(t<1){
        printf("Test na zestaw musi byc liczba naturalna wieksza od 0");
    }

    //init data
    p = malloc(sizeof(struct point)*nmax);
    tests = malloc(sizeof(struct point)*l);
    int rmax = 2*l;
    //printf("\n rands:\n");
    for(i=0;i<l;i++){
        tests[i].x = (rand() % rmax) - l;
        tests[i].y = (rand() % rmax) - l;
        //printf(" (%le, %le) ",tests[i].x,tests[i].y);
    }

    //tests
    FILE *pFile = fopen("out.txt","w");
    for(n=nmin;n<=nmax;n++){
        //create data
        p[0].x = 0;
        p[0].y = l;
        double step = 2*PI/n;
        int i2, i3;
        for(i2=1;i2<n;i2++){
            double k = step*i2;
            p[i2].x = p[0].y*sin(k) + p[0].x*cos(k);
            p[i2].y = p[0].y*cos(k) + p[0].x*sin(k);
        }

        //auto test
        //test correct polygon
        if(!isConvexPolygon(n, p)){
            printf("%d \n",n);
            continue;
        }

        //test by clock
        clock_t cB;
        clock_t tA, tB,tC;
        char rA, rB, rC;

        //test A
        cB = clock();
        for(i2=0;i2<l;i2++){
            for(i3=0;i3<t;i3++){
                goA(n, p, tP);
            }
        }
        tA = clock() - cB;

        //test B
        cB = clock();
        for(i2=0;i2<l;i2++){
            for(i3=0;i3<t;i3++){
                goB(n, p, tP);
            }
        }
        tB = clock() - cB;

        //test C
        cB = clock();
        for(i2=0;i2<l;i2++){
            for(i3=0;i3<t;i3++){
                goC(n, p, tP);
            }
        }
        tC = clock() - cB;

        //out
        double tsA =(double)tA/(double)CLOCKS_PER_SEC;
        double tsB =(double)tB/(double)CLOCKS_PER_SEC;
        double tsC =(double)tC/(double)CLOCKS_PER_SEC;
        //printf("%g seconds",seconds);
        printf("%d %f %f %f \n", n, tsA, tsB, tsC);
        fprintf(pFile, "%d %f %f %f \n", n, tsA, tsB, tsC);
    }
    fclose (pFile);

    return 0;
}

