#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define bool unsigned char
#define true 1
#define false 0

//Point Position
#define NO_ON 'N'
#define ON_CIRCUIT 'O'
#define ON_POLYGON 'P'
#define NaN 'E'

/*
 * DATA STRUCTURES
 */

struct point{
    double x, y;
};

struct lineFunction{
    double a,b;
};

/*struct triangle{
    struct point p1,p2,p3;
};*/

struct vector{
    double x,y;
};

struct anglesVector{
    double c, v;
};

struct anglesVector toAnglesVector(double x, double y){
    struct anglesVector av;
    av.c = atan2(x, y);
    av.v = sqrt((x * x) + (y * y));
    return av;
}

struct UV{
    double u,v;
};

/*
 * OPERTATIONS ON LINES
 */

struct lineFunction toLineFunction(struct point p1, struct point p2){
    struct lineFunction lf;
    lf.a = (p2.y-p1.y)/(p2.x-p1.x);
    lf.b = (p1.y-lf.a*p1.x);
    return lf;
};

unsigned char isOnLine(struct lineFunction lf, struct point p){
     double y = lf.a*p.x+lf.b;
     return y==p.y;
};

bool isBettwen(struct point p1, struct point p2, struct point pS){
    //select inly if point is in a quad
    double xMax, yMax, xMin, yMin;
    if(p1.x>p2.x){
        xMax = p1.x;
        xMin = p2.x;
    }else{
        xMax = p2.x;
        xMin = p1.x;
    }
    if(p1.y>p2.y){
        yMax = p1.y;
        yMin = p2.y;
    }else{
        yMax = p2.y;
        yMin = p1.y;
    }
    if(pS.x < xMin || pS.x>xMax || pS.y<yMin || pS.y>yMax){
        return false;
    }
    //on line
    if(xMax==xMin){
        return true;
    }
    struct lineFunction lf = toLineFunction(p1,p2);
    return isOnLine(lf, pS);
};

bool isOnCircuit(int n, struct point *p, struct point tP){
    int i;
    bool is;
    for(i=1;i<n;i++){
        is = isBettwen(p[i-1], p[i], tP);
        if(is){
            return true;
        }
    }
    is = isBettwen(p[n-1], p[0], tP);
    if(is){
        return true;
    }
    return false;
};

/*
 * OPERTATIONS ON POINTS
 */


struct vector subToVec(struct point A, struct point B){
        struct vector vec;
        vec.x = A.x - B.x;
        vec.y = A.y - B.y;
        return vec;
}


/*
 * OPERTATIONS ON VECTORS
 */

/*
 * Return side of point p -1 on left, 1 on right OR 0 if is on.
 */
 #define LEFT -1
 #define RIGHT 1
 #define ON 0



char pSide(struct point A, struct point B, struct point p){
    //if is vertical
    if(A.x==B.x){
        if(p.x==A.x){
            return ON;
        }
        int d = A.y<B.y? 1 : -1;
        return p.x<A.x ? LEFT*d : RIGHT*d;
    }
    //if horizontal or no vertical
    char d = A.x<B.x? 1 : -1;
    struct lineFunction lf = toLineFunction(A, B);
    double lineY = lf.a*p.x+lf.b;
    if(lineY==p.y){
        return ON;
    }
    if( lineY > p.y ){
        return RIGHT*d;
    }else{
        return LEFT*d;
    }
}

double dot(struct vector A, struct vector B){
        return (A.x*B.x + A.y*B.y);
}

struct vector sub(struct vector A, struct vector B){
        struct vector vec;
        vec.x = A.x - B.x;
        vec.y = A.y - B.y;
        return vec;
}

struct UV createUV(struct point A, struct point B, struct point C, struct point P){
    //VAR
    struct UV uv;

    // Compute vectors
    struct vector v0 = subToVec(C,A);
    struct vector v1 = subToVec(B,A);
    struct vector v2 = subToVec(P,A);

    // Compute dot products
    double dot00 = dot(v0, v0);
    double dot01 = dot(v0, v1);
    double dot02 = dot(v0, v2);
    double dot11 = dot(v1, v1);
    double dot12 = dot(v1, v2);

    // Compute barycentric coordinates
    double invDenom = 1 / (dot00 * dot11 - dot01 * dot01);
    uv.u = (dot11 * dot02 - dot01 * dot12) * invDenom;
    uv.v = (dot00 * dot12 - dot01 * dot02) * invDenom;

    return uv;
}

/*
 * OPERTATIONS ON TRIANGLE
 */


bool isOnTriangle(struct point A, struct point B, struct point C, struct point P){
    //specials
    if(A.x==B.x && isBettwen(A, B, P)){
        return true;
    }
    if(B.x==C.x && isBettwen(A, B, P)){
        return true;
    }

    //VAR
    struct UV uv = createUV(A, B, C, P);

    // Check if point is in triangle
    return (uv.u >= 0) && (uv.v >= 0) && (uv.u + uv.v <= 1);
}

/*
 * OPERTATIONS ON POLYGON
 */
 bool isOnPolygonByTriang(int n, struct point *p, struct point P){
     int i;
     for(i=2;i<n;i++){
        if(isOnTriangle(p[0], p[i], p[i-1], P)){
            return true;
        }
     }
     return false;
}

 bool isConvexPolygon(int n, struct point *p){
     int i;
     for(i=0;i<n-2;i++){
         if(pSide(p[i],p[i+2],p[i+1])!=LEFT){
            return false;
         }
     }
     if(pSide(p[n-1],p[1],p[0])!=LEFT){
         return false;
     }
     if(pSide(p[n-2],p[0],p[n-1])!=LEFT){
         return false;
     }
     return true;
}

/*
 * MAIN
 */

//test by triangles
char goA(int n, struct point *p, struct point tP){
    if( isOnCircuit(n, p, tP) ){
        return ON_CIRCUIT;
    }else if( isOnPolygonByTriang(n, p,tP) ){
        return ON_POLYGON;
    }else{
        return NO_ON;
    }
}

//test point inside the polygon by directiions
char goB(int n, struct point *p, struct point tP){
    int i;
    char w;
    for(i=1;i<n;++i){
        w = pSide(p[i-1], p[i], tP);
        if(w!=RIGHT){
            if(w==LEFT){
                return NO_ON;
            }else{
                if(isBettwen(p[i-1], p[i], tP)){
                    return ON_CIRCUIT;
                }
                return NO_ON;
            }
        }
    }
    w = pSide(p[n-1], p[0], tP);
    if(w==RIGHT){
        return ON_POLYGON;
    }
    if(w==LEFT){
        return NO_ON;
    }
    return ON_CIRCUIT;
}

//test point outside the polygon by directiions
char lineSide(struct lineFunction f1, double v, struct lineFunction f2){
    double x = (f1.b-f2.b)/(f2.a-f1.a);
    double y = f1.a*x+f1.b;
    double c = sqrt(x*x + y*y);
    if(v<c){
        return ON_POLYGON;
    }
    if(v==c){
        return ON_CIRCUIT;
    }
    return NO_ON;
}

char vSide(struct point *v1, struct point *v2){
    double mod_v1 = sqrt(v1->x*v1->x + v1->y*v1->y);
    double mod_v2 = sqrt(v2->x*v2->x + v2->y*v2->y);
    if(mod_v1<mod_v2){
        return ON_POLYGON;
    }
    if(mod_v1==mod_v2){
        return ON_CIRCUIT;
    }
    return NO_ON;
}

char _goC_Test(struct point pv, struct point p1, struct point p2){
    double cV1 = atan2(p1.x, p1.y);
    double cV2 = atan2(p2.x, p2.y);
    double cVT = atan2(pv.x, pv.y);
    if(cV1<cV2){
        if( cVT<cV1 || cVT>cV2 ){
            return NaN;
        }
    }else{
        if( cVT>cV2 && cVT<cV1 ){
            return NaN;
        }
    }
    struct lineFunction circuitFunction = toLineFunction(p1,p2);
    if(pv.x==0){
        struct point cV = {0, circuitFunction.b};
        return vSide(&pv, &cV);
    }
    struct point pc = {0,0};
    struct lineFunction lf = toLineFunction(pc, pv);
    if(p1.x==p2.x){
        struct point cV = {p1.x, lf.a*p1.x+lf.b};
        return vSide(&pv, &cV);
    }
    //return for two lines
    double v = sqrt(pv.x*pv.x + pv.y*pv.y);
    return lineSide(lf, v, circuitFunction);
}

char goC(int n, struct point *p, struct point tP){
    //math center
    int i;
    struct vector c;
    c.x = p[0].x;
    c.y = p[0].y;
    for(i=0;i<n;i++){
        c.x += p[i].x;
        c.y += p[i].y;
    }
    c.x /= n;
    c.y /= n;
    //
    struct point pv ={tP.x-c.x, tP.y-c.y};// pc = {0,0},
    //angel vector
    struct point p1, p2;
    //double cVT = atan2(pv.x, pv.y);
    for(i=1;i<n;++i){
        p1.x = p[i-1].x-c.x;
        p1.y = p[i-1].y-c.y;
        p2.x = p[i].x-c.x;
        p2.y = p[i].y-c.y;
        char r = _goC_Test(pv, p1, p2);
        if(r!=NaN){
            return r;
        }
    }
    p1.x = p[n-1].x-c.x;
    p1.y = p[n-1].y-c.y;
    p2.x = p[0].x-c.x;
    p2.y = p[0].y-c.y;
    return _goC_Test(pv, p1, p2);
}
