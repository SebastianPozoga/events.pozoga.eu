#include <stdio.h>
#include <stdlib.h>
#include "lib.c"


int main()
{
    //nuber of polygon points
    int n;
    //polygon points
    struct point *p;
    //test point
    struct point tP;
    //helpers
    int i;

    //get number of points of polygon
    do{
        scanf("%i",&n);
        if(n>=3){
            break;
        }
        printf("\n N must be greater than 3! Insert again:\n");
    }while(1==1);

    //init data
    p = malloc(sizeof(struct point)*n);
    for(i=0;i<n;i++){
        scanf("%le %le", &p[i].x, &p[i].y);
    }

    //test correct polygon
    if(!isConvexPolygon(n, p)){
        printf("I\n");
        return 0;
    }

    //Test points
    int t;
    scanf("%d",&t);
    for(i=0;i<t;i++){
        scanf("%le %le", &tP.x, &tP.y);
        char wA = goA(n, p, tP);
        char wB = goB(n, p, tP);
        char wC = goC(n, p, tP);
        if(wA!=wB || wB!=wC){
            printf("A(%c) B(%c) C(%c) <- EQUALS ERROR\n",wA,wB,wC);
        }else{
            printf("%c\n",wA);
        }
    }
    return 0;
}
