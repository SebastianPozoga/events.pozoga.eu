#include <stdio.h>
#include <stdlib.h>
#include "lib.c"

#define PI 3.141592653589793238462


int main()
{
    //nuber of polygon points
    int n, l;
    //polygon points
    struct point *p;
    //test point
    //struct point tP;
    //helpers
    int i1,i2;
    double x,y;
    //file
    FILE *fo, *fi;
    char fname[150];
    char foutname[150];

    //get polygons interval
    printf("\nPodaj ilosc bokow wielokata: ");
    scanf("%i", &n);
    if(n<3){
        printf("Wielokat musi skladac sie z conajmniej 3 bokow");
        return 0;
    }
    printf("\nIlosc testow: ");
    scanf("%i", &l);
    if(l<1){
        printf("Minimalna ilosc testow to 1");
    }
    printf("\nNazwa pliku wynikowago (.in): ");
    scanf("%s", &fname);
    printf("\nNazwa pliku wynikowago (.out): ");
    scanf("%s", &foutname);

    //init data
    p = malloc(sizeof(struct point)*n);
    fi=fopen(fname, "w");
    fo=fopen(foutname, "w");

    //create polygon
    p[0].x = 0;
    p[0].y = l;
    double step = 2*PI/n;
    for(i2=1;i2<n;i2++){
        double k = step*i2;
        p[i2].x = p[0].y*sin(k) + p[0].x*cos(k);
        p[i2].y = p[0].y*cos(k) + p[0].x*sin(k);
        //fprintf(fi, "%le %le\n", p[i2].x, p[i2].y);
    }


    //out
    fprintf(fi, "%d\n", n);
    for(i2=0;i2<n;i2++){
        fprintf(fi, "%f %f\n", p[i2].x, p[i2].y);
    }

    //test correct polygon
    if(!isConvexPolygon(n, p)){
        fprintf(fo, "I\n");
        fclose(fi);
        fclose(fo);
        return 0;
    }

    //tests
    int rmax = 2*l;
    fprintf(fi, "%d\n", l);
    for(i1=0;i1<=l;i1++){
        //prepare data
        x = (rand() % rmax) - l;
        y = (rand() % rmax) - l;
        struct point tP = {x, y};
        fprintf(fi, "%f %f\n", x, y);
        //test
        char wA = goA(n, p, tP);
        char wB = goB(n, p, tP);
        char wC = goC(n, p, tP);
        if(wA!=wB || wB!=wC){
            //Out when incorrect
            printf("A(%c) B(%c) C(%c) <- EQUALS ERROR\n",wA,wB,wC);
            fprintf(fo, "A(%c) B(%c) C(%c) <- EQUALS ERROR\n",wA,wB,wC);
        }else{
            //Out when correct
            fprintf(fo, "%c\n",wA);
        }
    }

    fclose(fi);
    fclose(fo);
    return 0;
}

