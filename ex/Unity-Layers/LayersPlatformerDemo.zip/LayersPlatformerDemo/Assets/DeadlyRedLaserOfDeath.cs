﻿using UnityEngine;

[RequireComponent(typeof (LineRenderer))]
public class DeadlyRedLaserOfDeath : MonoBehaviour
{
    public Transform LaserSource;
    private PlayerController _controller;
    private LineRenderer _laser;

    private void Awake()
    {
        _laser = GetComponent<LineRenderer>();
        _controller = GetComponent<PlayerController>();
    }

    private void Update()
    {
        if (Input.GetKey(KeyCode.F))
        {
            _laser.enabled = true;
            _laser.SetPosition(0, LaserSource.position);

            RaycastHit hitInfo;
            Vector3 laserDirection = _controller.IsRightFacing ? Vector3.right : -Vector3.right;
            Physics.Raycast(LaserSource.position, laserDirection, out hitInfo, 100);

            if (hitInfo.collider.tag == "Enemy")
            {
                Destroy(hitInfo.collider.gameObject);
            }
            _laser.SetPosition(1, hitInfo.point);
            _laser.enabled = true;
        }
        else
        {
            _laser.enabled = false;
        }
    }
}