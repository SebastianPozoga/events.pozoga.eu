﻿using UnityEngine;
public class PlayerController : MonoBehaviour
{
    public float AccelerationForce;
    public float JumpForce;
    public Transform PlayerModel;
    public GameObject WinScreen;
    public GameObject LoseScreen;

    public bool IsRightFacing = true;
    private Transform _myTransform;
    private Rigidbody _myRigidbody;
    private bool _isGrounded = true;

    void Awake()
    {
        _myRigidbody = rigidbody;
        _myTransform = transform;
    }

    void Update()
    {
        if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A))
        {
            if (IsRightFacing)
            {
                Turn();
            }
            _myRigidbody.AddForce(-Vector3.right * AccelerationForce);
        }
        else if (Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D))
        {
            if (!IsRightFacing)
            {
                Turn();
            }
            _myRigidbody.AddForce(Vector3.right * AccelerationForce);
        }

        if (_isGrounded && Input.GetKey(KeyCode.Space))
        {
            _myRigidbody.AddForce(Vector3.up * JumpForce);
            _isGrounded = false;
        }
    }

    void OnCollisionEnter(Collision col)
    {
        if (Physics.Raycast(_myTransform.position, Vector3.down, 0.5f))
        {
            _isGrounded = true;
        }

        if (col.collider.tag == "Enemy")
        {
            LoseScreen.SetActive(true);
        }

        if (col.collider.tag == "Finish")
        {
            WinScreen.SetActive(true);
        }
    }

    void Turn()
    {
        IsRightFacing = !IsRightFacing;
        Vector3 scale = PlayerModel.localScale;
        scale.x *= -1;
        PlayerModel.localScale = scale;
    }
}