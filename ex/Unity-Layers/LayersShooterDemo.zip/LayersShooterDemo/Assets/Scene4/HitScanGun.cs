﻿using UnityEngine;
public class HitScanGun : MonoBehaviour
{
    public Transform BulletSource;
    public LineRenderer LaserTrail;

    void Update()
    {
        RaycastHit hitInfo;
        if (!Input.GetMouseButton(1))
        {
            // We are not shooting lasers, nothing to do here
            LaserTrail.enabled = false;
            return;
        }

        // Find out where the laser hits, position the line, enable line renderer;
        int layermask = 0;
        layermask = layermask | 1 | (1 << 8) | (1 << 11);

        Physics.Raycast(BulletSource.position, BulletSource.forward, out hitInfo, 400, layermask);

        LaserTrail.enabled = true;
        LaserTrail.SetPosition(0, BulletSource.position);

        if (hitInfo.distance <= 0)
        {
            // If we are shooting at the sky, just draw a long laser line forward 
            LaserTrail.SetPosition(1, BulletSource.position + BulletSource.forward * 100);
            return;
        }

        LaserTrail.SetPosition(1, hitInfo.point);

        // If we hit an enemy, kill him
        var enemy = hitInfo.collider.GetComponent<EnemyController>();
        if (enemy != null)
        {
            enemy.TakeDamage();
        }
        

       
    }
}