﻿using UnityEngine;
public class Bullet : MonoBehaviour
{
    public float Speed;

    void Start()
    {
        rigidbody.velocity = transform.forward * Speed;
    }

    void OnCollisionEnter(Collision collision)
    {
        var enemy = collision.collider.GetComponent<EnemyController>();
        if (enemy != null)
        {
            enemy.TakeDamage();
        }

        Destroy(gameObject);
    }
}