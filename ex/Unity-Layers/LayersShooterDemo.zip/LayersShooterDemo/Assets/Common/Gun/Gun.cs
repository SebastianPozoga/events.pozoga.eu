﻿using UnityEngine;
public class Gun : MonoBehaviour
{
    public Transform bulletSource;
    public GameObject bulletPrefab;

    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            GameObject.Instantiate(bulletPrefab, bulletSource.position, bulletSource.rotation);
        }
    }
}