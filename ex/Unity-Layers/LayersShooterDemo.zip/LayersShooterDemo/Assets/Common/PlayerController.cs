﻿using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public Transform Camera;
    public float MoveSpeed;
    public float XRotationSpeed;
    public float YRotationSpeed;
    private Transform _myTransform;
    private CharacterController _controller;

    private void Awake()
    {
        _controller = GetComponent<CharacterController>();
        _myTransform = transform;
    }

    private void Update()
    {
        float rotDeltaX = Input.GetKey(KeyCode.RightArrow) ? XRotationSpeed : 0;
        rotDeltaX -= Input.GetKey(KeyCode.LeftArrow) ? XRotationSpeed : 0;
        float rotDeltaY = Input.GetKey(KeyCode.DownArrow) ? YRotationSpeed : 0;
        rotDeltaY -= Input.GetKey(KeyCode.UpArrow) ? YRotationSpeed : 0;
        Camera.Rotate(Vector3.right, rotDeltaY);
        _myTransform.Rotate(Vector3.up, rotDeltaX);

        Vector3 moveDeltaX = _myTransform.forward * MoveSpeed;
        if (Input.GetKey(KeyCode.S))
        {
            moveDeltaX *= -1;
        }
        else if (!Input.GetKey(KeyCode.W))
        {
            moveDeltaX = Vector3.zero;
        }

        Vector3 moveDeltaY = _myTransform.right * MoveSpeed;
        if (Input.GetKey(KeyCode.A))
        {
            moveDeltaY *= -1;
        }
        else if (!Input.GetKey(KeyCode.D))
        {
            moveDeltaY = Vector3.zero;
        }

        _controller.Move(moveDeltaX + moveDeltaY);
    }
}