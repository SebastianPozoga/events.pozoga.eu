﻿using UnityEngine;

public class CubeMover : MonoBehaviour
{
    void Update()
    {
        transform.position += new Vector3(0, 0, 0.1f);
    }
}