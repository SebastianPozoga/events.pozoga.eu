﻿using UnityEngine;

public class EnemyController : MonoBehaviour
{
    private int hp = 10;
    public void TakeDamage()
    {
        hp--;
        if (hp <= 0)
        {
            Destroy(gameObject);
        }
    }
}